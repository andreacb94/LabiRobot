//
//  L298NDRIVER.h
//  
//
//  Created by Andrea Petrella on 14/10/17.
//
//

#ifndef L298NDRIVER_H
#define L298NDRIVER_H

#include <Arduino.h>

class L298NDRIVER
{
    public:

    void stopMotor(int en1, int en2);
    void setPower(int pin, int pw);
    void setForwardMove(int en1, int en2);
    void setBackwardMove(int en1, int en2);
    void setRotateSX(int en1, int en2, int en3, int en4);
    void setRotateDX(int en1, int en2, int en3, int en4);
};

#endif
