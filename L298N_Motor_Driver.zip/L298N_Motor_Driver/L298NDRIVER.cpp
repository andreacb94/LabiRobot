//
//  L298NDRIVER.cpp
//  
//
//  Created by Andrea Petrella on 14/10/17.
//
//

/*
 
 Libreria per gestire i pin della scheda L298N dei motori DC
 
 */

#include "L298NDRIVER.h"

/*
 
 True Table of ens pins
 
   en1   |    en2   | Even
 --------|----------|-----------------
 LOW     |    LOW   | stop
 LOW     |   HIGH   | move forward
 HIGH    |    LOW   | move backwards
 HIGH    |   HIGH   | stop
 
 */


//Stop motor
void L298NDRIVER::stopMotor(int en1, int en2){
    
    
    digitalWrite(en1, LOW);
    digitalWrite(en2, LOW);
    
}

//Set power of motor
void L298NDRIVER::setPower(int pin, int pw){
    
    analogWrite(pin, pw);
    
}

//Set forward move
void L298NDRIVER::setForwardMove(int en1, int en2){
    
    
    digitalWrite(en1, LOW);
    digitalWrite(en2, HIGH);
    
}

//Set backorward move
void L298NDRIVER::setBackwardMove(int en1, int en2){
    
    
    digitalWrite(en1, HIGH);
    digitalWrite(en2, LOW);
    
}

//Set rotate to left
void L298NDRIVER::setRotateSX(int en1, int en2, int en3, int en4){
    
    //Invert sense of left motor
    L298NDRIVER::setBackwardMove(en1, en2);
    
    //Go forward with right motor
    L298NDRIVER::setForwardMove(en3, en4);
    
}

//Set rotate to right
void L298NDRIVER::setRotateDX(int en1, int en2, int en3, int en4){
    
    //Invert sense of right motor
    L298NDRIVER::setBackwardMove(en3, en4);
    
    //Go forward with left motor
    L298NDRIVER::setForwardMove(en1, en2);
    
}

























